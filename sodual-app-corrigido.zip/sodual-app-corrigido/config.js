/* Gerado por tools/gen_config.mjs - nao edite. */
window.SODUAL_CONFIG = {
 "supabaseUrl": "https://shlmxdbumlapkkmjjzsp.supabase.co",
 "supabaseKey": "sb_publishable_3cUUKin2D9pfgq7-fTrn-w_vvsJ2atU",
 "siteUrl": "",
 "senhaMin": 8,
 "senhaReq": ""
};
